A package for finding the various calculations about microtubule catastrophe.

Calculates the needed confidence intervals and maximum likelihood estimators,
and it also includes analysis functions to evaluate the MLEs.